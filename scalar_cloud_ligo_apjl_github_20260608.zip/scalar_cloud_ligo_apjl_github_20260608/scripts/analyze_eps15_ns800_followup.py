from __future__ import annotations

import math
import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from make_cloud_exclusion_intervals import main as make_intervals_main


ROOT = Path(__file__).resolve().parent
DEFAULT_BASE = ROOT / "t" / "eps15_ns800_followup_results_20260607_091607"
BASE = DEFAULT_BASE
MU = BASE / "mu_grid"
CTX = BASE / "eps15_followup_campaigns" / "all_exclusion_ns800" / "context.csv"
OUT = ROOT / "analysis_outputs" / "eps15_ns800_followup_analysis"


def load_ns800_points() -> pd.DataFrame:
    frames = []
    for path in sorted(MU.glob("*Nmu31_Ns800.csv")):
        df = pd.read_csv(path)
        df["source_file"] = path.name
        frames.append(df)
    if not frames:
        raise FileNotFoundError(f"No *Nmu31_Ns800.csv files under {MU}")
    return pd.concat(frames, ignore_index=True)


def write_clean_input(points: pd.DataFrame) -> Path:
    OUT.mkdir(parents=True, exist_ok=True)
    clean = points.copy()
    clean.to_csv(OUT / "eps15_ns800_all_mu_points_raw.csv", index=False)
    return OUT / "eps15_ns800_all_mu_points_raw.csv"


def summarize_coverage(points: pd.DataFrame) -> pd.DataFrame:
    ctx = pd.read_csv(CTX)
    done = (
        points[["event", "host", "detectors", "posterior_group", "n_posterior_used", "source_file"]]
        .drop_duplicates(["event", "host", "detectors"])
        .copy()
    )
    ctx_keys = ctx[["event", "host", "detectors", "posterior_group", "rank", "best_model_to_limit_ratio"]].drop_duplicates()
    merged = ctx_keys.merge(done, on=["event", "host", "detectors"], how="left", suffixes=("_target", "_result"))
    merged["has_ns800_csv"] = merged["source_file"].notna()
    merged.to_csv(OUT / "eps15_ns800_campaign_coverage.csv", index=False)
    return merged


def contiguous_intervals(values: list[float], gap_factor: float = 1.8) -> list[tuple[float, float, int]]:
    if not values:
        return []
    values = sorted(values)
    intervals = []
    start = prev = values[0]
    n = 1
    for x in values[1:]:
        if prev > 0 and x / prev <= gap_factor:
            prev = x
            n += 1
        else:
            intervals.append((start, prev, n))
            start = prev = x
            n = 1
    intervals.append((start, prev, n))
    return intervals


def make_direct_summary(points: pd.DataFrame) -> pd.DataFrame:
    rows = []
    clean = points[
        (pd.to_numeric(points["logB_reweighted_resonance_gr"], errors="coerce") <= 3.0)
        & (pd.to_numeric(points["valid_mapping_fraction"], errors="coerce") >= 0.5)
    ].copy()
    for (event, host, det), group in clean.groupby(["event", "host", "detectors"]):
        best = group.sort_values("sc_95_from_abs_a").iloc[0]
        rows.append(
            {
                "event": event,
                "host": host,
                "detectors": det,
                "posterior_group": best["posterior_group"],
                "n_points_clean": len(group),
                "best_sc95_ns800": best["sc_95_from_abs_a"],
                "best_mu_eV_ns800": best["mu_eV"],
                "best_f_res_hz_ns800": best["f_res_hz"],
                "best_logB_ns800": best["logB_reweighted_resonance_gr"],
                "max_logB_ns800": group["logB_reweighted_resonance_gr"].max(),
                "min_sc95_prior_limited": group["sc_95_prior_limited"].astype(str).str.lower().eq("true").any(),
            }
        )
    out = pd.DataFrame(rows).sort_values("best_sc95_ns800")
    out.to_csv(OUT / "eps15_ns800_direct_summary.csv", index=False)
    return out


def compare_with_ns400(ns800_summary: pd.DataFrame) -> pd.DataFrame:
    old_path = ROOT / "G_PRL_eps15_summary_shadow.csv"
    candidates = [
        Path("G:/PRL云/cloud_history_eps15_clean_constraints.csv"),
        Path("G:/PRL云/cloud_history_eps15_summary.csv"),
        ROOT / "posterior_reweight_catalog/cloud_model/cloud_history_eps15_summary.csv",
    ]
    old = None
    for p in candidates:
        if p.exists():
            old = pd.read_csv(p)
            break
    if old is None:
        return pd.DataFrame()
    old.to_csv(old_path, index=False)
    old_cols = [c for c in ["event", "host", "detectors", "sc_95_from_abs_a", "mu_eV", "f_res_hz", "logB_reweighted_resonance_gr"] if c in old.columns]
    if {"event", "host", "detectors", "sc_95_from_abs_a"}.issubset(old_cols):
        old_best = old.sort_values("sc_95_from_abs_a").drop_duplicates(["event", "host", "detectors"])
        old_best = old_best[old_cols].rename(
            columns={
                "sc_95_from_abs_a": "best_sc95_ns400",
                "mu_eV": "best_mu_eV_ns400",
                "f_res_hz": "best_f_res_hz_ns400",
                "logB_reweighted_resonance_gr": "best_logB_ns400",
            }
        )
        cmp = ns800_summary.merge(old_best, on=["event", "host", "detectors"], how="left")
        cmp["sc95_ns800_over_ns400"] = cmp["best_sc95_ns800"] / cmp["best_sc95_ns400"]
        cmp.to_csv(OUT / "eps15_ns800_vs_ns400_direct_comparison.csv", index=False)
        return cmp
    return pd.DataFrame()


def plot_direct(summary: pd.DataFrame, coverage: pd.DataFrame) -> None:
    top = summary.head(20).copy()
    fig, ax = plt.subplots(figsize=(7.0, 5.2))
    labels = [f"{r.event.replace('_', ' ')} {r.host}" for r in top.itertuples()]
    colors = ["#334155" if x <= 3 else "#b45309" for x in top["best_logB_ns800"]]
    ax.barh(range(len(top)), top["best_sc95_ns800"], color=colors, height=0.72)
    ax.set_yticks(range(len(top)))
    ax.set_yticklabels(labels, fontsize=7)
    ax.invert_yaxis()
    ax.set_xscale("log")
    ax.set_xlabel(r"best clean $S_c/M^2$ 95% upper limit, Ns=800")
    ax.grid(axis="x", alpha=0.25)
    ax.set_title("eps=15 broad follow-up: direct constraints")
    fig.tight_layout()
    fig.savefig(OUT / "eps15_ns800_direct_top20.png", dpi=260)
    fig.savefig(OUT / "eps15_ns800_direct_top20.pdf")

    miss = coverage[~coverage["has_ns800_csv"]].copy()
    fig, ax = plt.subplots(figsize=(7.0, 3.0))
    ax.axis("off")
    lines = [
        f"Target branches: {len(coverage)}",
        f"Branches with Ns=800 CSV: {int(coverage['has_ns800_csv'].sum())}",
        f"Missing branches: {len(miss)}",
        "",
    ]
    lines += [f"{r.event} {r.host} {r.detectors}" for r in miss.head(14).itertuples()]
    ax.text(0.02, 0.96, "\n".join(lines), va="top", ha="left", fontsize=9, family="monospace")
    fig.tight_layout()
    fig.savefig(OUT / "eps15_ns800_coverage.png", dpi=220)
    fig.savefig(OUT / "eps15_ns800_coverage.pdf")


def run_interval_model(clean_csv: Path) -> None:
    # Run the existing interval model by spawning it as a subprocess.  This keeps
    # argparse state isolated and preserves the exact published script behavior.
    import subprocess
    import sys

    outdir = OUT / "cloud_exclusion_intervals_eps15_ns800_detailed"
    cmd = [
        sys.executable,
        str(ROOT / "make_cloud_exclusion_intervals.py"),
        "--clean-csv",
        str(clean_csv),
        "--outdir",
        str(outdir),
        "--eps-values",
        "15",
        "--saturation-model",
        "detailed",
        "--min-delay-years",
        "1e8",
        "--max-logb",
        "3",
        "--min-valid-fraction",
        "0.5",
    ]
    subprocess.run(cmd, cwd=ROOT, check=True)


def write_report(coverage: pd.DataFrame, direct: pd.DataFrame, comparison: pd.DataFrame) -> None:
    interval_dir = OUT / "cloud_exclusion_intervals_eps15_ns800_detailed"
    intervals = pd.read_csv(interval_dir / "cloud_exclusion_intervals_by_source.csv") if (interval_dir / "cloud_exclusion_intervals_by_source.csv").exists() else pd.DataFrame()
    source_summary = pd.read_csv(interval_dir / "cloud_exclusion_source_summary.csv") if (interval_dir / "cloud_exclusion_source_summary.csv").exists() else pd.DataFrame()
    missing = coverage[~coverage["has_ns800_csv"]].copy()

    def md_table(df: pd.DataFrame, cols: list[str] | None = None, max_rows: int | None = None) -> str:
        if cols is not None:
            df = df[cols]
        if max_rows is not None:
            df = df.head(max_rows)
        if df.empty:
            return "_empty_"
        work = df.copy()
        for col in work.columns:
            if pd.api.types.is_float_dtype(work[col]):
                work[col] = work[col].map(lambda x: "" if pd.isna(x) else f"{x:.5g}")
            else:
                work[col] = work[col].map(lambda x: "" if pd.isna(x) else str(x))
        header = "| " + " | ".join(work.columns) + " |"
        sep = "| " + " | ".join(["---"] * len(work.columns)) + " |"
        body = ["| " + " | ".join(str(row[c]) for c in work.columns) + " |" for _, row in work.iterrows()]
        return "\n".join([header, sep] + body)

    lines = []
    lines.append("# eps=15 Ns=800 follow-up analysis\n")
    lines.append(f"- Target broad branches: {len(coverage)}")
    lines.append(f"- Branches with usable Ns=800 CSV: {int(coverage['has_ns800_csv'].sum())}")
    lines.append(f"- Missing broad branches: {len(missing)}")
    lines.append(f"- Direct clean summaries: {len(direct)}")
    lines.append(f"- Detailed-model interval rows: {len(intervals)}")
    if len(intervals):
        lines.append(f"- Branches retaining detailed-model intervals: {intervals[['event','host']].drop_duplicates().shape[0]}")
    lines.append("\n## Missing branches\n")
    if len(missing):
        lines.append(md_table(missing, ["rank", "event", "host", "detectors", "best_model_to_limit_ratio"]))
    else:
        lines.append("None.")
    lines.append("\n## Top direct Ns=800 limits\n")
    lines.append(md_table(direct, ["event", "host", "detectors", "best_sc95_ns800", "best_mu_eV_ns800", "best_f_res_hz_ns800", "best_logB_ns800"], 20))
    if len(intervals):
        lines.append("\n## Detailed saturated-cloud intervals, Ns=800 input\n")
        cols = [c for c in ["event", "host", "mu_low_eV", "mu_high_eV", "f_low_hz", "f_high_hz", "n_points", "best_model_to_limit_ratio"] if c in intervals.columns]
        lines.append(md_table(intervals.sort_values("best_model_to_limit_ratio", ascending=False), cols, 40))
    if len(comparison):
        lines.append("\n## Ns=800 / Ns=400 direct-limit comparison\n")
        cols = [c for c in ["event","host","detectors","best_sc95_ns800","best_sc95_ns400","sc95_ns800_over_ns400","best_logB_ns800"] if c in comparison.columns]
        lines.append(md_table(comparison.sort_values("best_sc95_ns800"), cols, 30))
    (OUT / "eps15_ns800_followup_report.md").write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize eps=15 Ns=800 follow-up runs.")
    parser.add_argument("--base", type=Path, default=DEFAULT_BASE, help="Directory containing posterior_reweight_catalog/mu_grid or mu_grid.")
    parser.add_argument("--context-csv", type=Path, default=None, help="Campaign context.csv for coverage accounting.")
    parser.add_argument("--outdir", type=Path, default=OUT, help="Output directory.")
    return parser.parse_args()


def configure_paths(args: argparse.Namespace) -> None:
    global BASE, MU, CTX, OUT
    BASE = args.base.resolve()
    if (BASE / "posterior_reweight_catalog" / "mu_grid").exists():
        MU = BASE / "posterior_reweight_catalog" / "mu_grid"
    else:
        MU = BASE / "mu_grid"
    if args.context_csv is not None:
        CTX = args.context_csv.resolve()
    elif (BASE / "eps15_followup_resume_campaigns" / "all_exclusion_ns800" / "context.csv").exists():
        CTX = BASE / "eps15_followup_resume_campaigns" / "all_exclusion_ns800" / "context.csv"
    else:
        CTX = BASE / "eps15_followup_campaigns" / "all_exclusion_ns800" / "context.csv"
    OUT = args.outdir.resolve()


def main() -> None:
    configure_paths(parse_args())
    OUT.mkdir(parents=True, exist_ok=True)
    points = load_ns800_points()
    clean_csv = write_clean_input(points)
    coverage = summarize_coverage(points)
    direct = make_direct_summary(points)
    comparison = compare_with_ns400(direct)
    plot_direct(direct, coverage)
    run_interval_model(clean_csv)
    write_report(coverage, direct, comparison)
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
