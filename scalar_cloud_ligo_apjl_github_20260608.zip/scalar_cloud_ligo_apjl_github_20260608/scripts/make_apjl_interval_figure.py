from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
OUTDIR = ROOT / "apjl_scalar_cloud_resonance" / "figures"
NS800_CANDIDATES = [
    ROOT
    / "analysis_outputs"
    / "eps15_ns800_final_20260608_175421"
    / "cloud_exclusion_intervals_eps15_ns800_detailed"
    / "cloud_exclusion_intervals_by_source.csv",
    ROOT
    / "analysis_outputs"
    / "eps15_ns800_followup_analysis"
    / "cloud_exclusion_intervals_eps15_ns800_detailed"
    / "cloud_exclusion_intervals_by_source.csv",
]
FALLBACK = ROOT / "apjl_scalar_cloud_resonance" / "tables" / "cloud_exclusion_intervals_eps15_detailed.csv"

RUN_COLORS = {
    "O1": "#7B61D1",
    "O2": "#63A95D",
    "O3": "#087C83",
    "O4": "#E1661A",
    "GWTC-4.1": "#E1661A",
    "GWTC-5.0": "#E1661A",
}


def setup() -> None:
    mpl.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "Nimbus Roman", "DejaVu Serif"],
            "mathtext.fontset": "stix",
            "axes.linewidth": 0.65,
            "xtick.major.width": 0.65,
            "ytick.major.width": 0.65,
            "xtick.minor.width": 0.55,
            "ytick.minor.width": 0.55,
            "axes.labelsize": 8.5,
            "axes.titlesize": 9.2,
            "xtick.labelsize": 7.8,
            "ytick.labelsize": 7.3,
            "legend.fontsize": 7.2,
            "figure.dpi": 190,
            "savefig.dpi": 420,
        }
    )


def run_color(run: str) -> str:
    run = str(run)
    if run in RUN_COLORS:
        return RUN_COLORS[run]
    if "O4" in run or "GWTC-4" in run or "GWTC-5" in run:
        return RUN_COLORS["O4"]
    if "O3" in run:
        return RUN_COLORS["O3"]
    if "O2" in run:
        return RUN_COLORS["O2"]
    if "O1" in run:
        return RUN_COLORS["O1"]
    return "#6B7280"


def normalize_run(run: str) -> str:
    run = str(run)
    if "O4" in run or "GWTC-4" in run or "GWTC-5" in run:
        return "O4"
    if "O3" in run:
        return "O3"
    if "O2" in run:
        return "O2"
    if "O1" in run:
        return "O1"
    return run


def host_math(host: str) -> str:
    host = str(host)
    if host.startswith("m") and host[1:].isdigit():
        return rf"$m_{{{host[1:]}}}$"
    return host


def load_intervals() -> pd.DataFrame:
    path = next((p for p in NS800_CANDIDATES if p.exists()), FALLBACK)
    df = pd.read_csv(path)
    rename = {
        "best_ratio": "best_model_to_limit_ratio",
        "mu_low": "mu_low_eV",
        "mu_high": "mu_high_eV",
        "best_mu": "best_mu_eV",
    }
    df = df.rename(columns={k: v for k, v in rename.items() if k in df.columns})
    needed = ["event", "host", "observing_run", "mu_low_eV", "mu_high_eV", "best_mu_eV", "n_points", "best_model_to_limit_ratio"]
    missing = [c for c in needed if c not in df.columns]
    if missing:
        raise RuntimeError(f"Missing columns in {path}: {missing}")
    df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=needed)
    df = df.sort_values(["best_model_to_limit_ratio", "n_points"], ascending=[False, False])
    return df.head(30).reset_index(drop=True)


def draw_event_labels(ax, df: pd.DataFrame, y: np.ndarray) -> None:
    ax.set_xlim(0, 1)
    ax.set_ylim(-0.75, len(df) - 0.25)
    ax.axis("off")
    ax.text(0.02, len(df) - 0.1, "Event", fontsize=8.6, weight="bold", ha="left", va="bottom")
    for i, row in df.iterrows():
        yy = y[i]
        rank = i + 1
        run = normalize_run(row["observing_run"])
        ax.scatter(0.035, yy, s=58, color="#061226", zorder=4)
        ax.text(0.035, yy, f"{rank}", color="white", fontsize=5.2, ha="center", va="center", weight="bold", zorder=6)
        ax.text(0.085, yy, f"{row['event']} {host_math(row['host'])}", fontsize=6.4, ha="left", va="center", color="#111827")
        ax.text(0.985, yy, f"[{run}]", fontsize=6.5, ha="right", va="center", color=run_color(run))


def main() -> None:
    setup()
    OUTDIR.mkdir(parents=True, exist_ok=True)
    df = load_intervals()
    y = np.arange(len(df))[::-1]
    colors = [run_color(r) for r in df["observing_run"]]
    ratios = df["best_model_to_limit_ratio"].astype(float).to_numpy()
    ratio_norm = Normalize(vmin=float(np.nanmin(ratios)), vmax=float(np.nanmax(ratios)))
    ratio_cmap = plt.get_cmap("viridis")

    fig = plt.figure(figsize=(9.1, 5.82), constrained_layout=False)
    fig.patch.set_facecolor("#FEFEFC")
    gs = fig.add_gridspec(1, 3, width_ratios=[1.55, 3.85, 1.18], left=0.035, right=0.982, top=0.825, bottom=0.105, wspace=0.035)
    axlab = fig.add_subplot(gs[0, 0])
    ax = fig.add_subplot(gs[0, 1], sharey=axlab)
    axr = fig.add_subplot(gs[0, 2], sharey=axlab)

    draw_event_labels(axlab, df, y)

    ax.set_xscale("log")
    xmin = min(1.7e-12, float(df["mu_low_eV"].min()) * 0.82)
    xmax = max(5.4e-12, float(df["mu_high_eV"].max()) * 1.18)
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(-0.75, len(df) - 0.25)
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position("top")
    ax.set_xlabel(r"Excluded boson mass $\mu$ [eV]", labelpad=5, weight="bold")
    ax.tick_params(axis="y", left=False, labelleft=False)
    ax.grid(axis="x", which="major", color="#CBD5E1", lw=0.6, ls=":")
    ax.grid(axis="y", which="major", color="#CBD5E1", lw=0.55, ls=(0, (2, 3)))
    ax.set_yticks(y)

    band_lo, band_hi = 3.0e-12, 4.0e-12
    ax.axvspan(band_lo, band_hi, color="#EAF2FF", alpha=0.75, zorder=-4)

    for i, row in df.iterrows():
        lo = float(row["mu_low_eV"])
        hi = float(row["mu_high_eV"])
        best = float(row["best_mu_eV"])
        c = colors[i]
        yy = y[i]
        if int(row["n_points"]) > 1 and hi > lo:
            ax.plot([lo, hi], [yy, yy], color=c, lw=4.1, alpha=0.78, solid_capstyle="round")
            ax.plot([lo, hi], [yy, yy], color=c, lw=2.0, alpha=0.98, solid_capstyle="round")
            ax.scatter(best, yy, s=22, color="#050816", zorder=5, edgecolor="white", linewidth=0.35)
        else:
            ax.scatter(best, yy, s=36, marker="D", facecolor="white", edgecolor="#050816", linewidth=1.0, zorder=5)

    for sp in ax.spines.values():
        sp.set_linewidth(0.65)
    ax.add_patch(FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0.006,rounding_size=0.018", transform=ax.transAxes, fc="none", ec="#0F172A", lw=0.65, clip_on=False))

    axr.set_xscale("log")
    axr.set_xlim(1.0, max(120.0, ratios.max() * 1.25))
    axr.xaxis.tick_top()
    axr.xaxis.set_label_position("top")
    axr.set_xlabel("Model / limit (dimensionless)", labelpad=5, weight="bold")
    axr.tick_params(axis="y", left=False, labelleft=False)
    axr.set_yticks(y)
    axr.grid(axis="x", which="major", color="#CBD5E1", lw=0.55, ls=":")
    axr.grid(axis="y", which="major", color="#CBD5E1", lw=0.50, ls=(0, (2, 3)))
    axr.axvspan(1.0, max(120.0, ratios.max() * 1.25), color="#FFF2E5", alpha=0.78, zorder=-5)
    axr.axvline(1.0, color="#64748B", lw=0.75, ls="--")
    for i, row in df.iterrows():
        ratio = float(row["best_model_to_limit_ratio"])
        c = ratio_cmap(ratio_norm(ratio))
        yy = y[i]
        axr.plot([1.0, ratio], [yy, yy], color=c, lw=0.95, alpha=0.75)
        axr.scatter(ratio, yy, s=25, color=c, edgecolor="white", linewidth=0.35, zorder=4)
    axr.add_patch(FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0.006,rounding_size=0.035", transform=axr.transAxes, fc="none", ec="#0F172A", lw=0.65, clip_on=False))

    handles = [
        Line2D([0], [0], color=RUN_COLORS["O3"], lw=4, label="O3"),
        Line2D([0], [0], color=RUN_COLORS["O4"], lw=4, label="O4"),
        Line2D([0], [0], color=RUN_COLORS["O2"], lw=4, label="O2"),
        Line2D([0], [0], color=RUN_COLORS["O1"], lw=4, label="O1"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor="#050816", markeredgecolor="#050816", markersize=5, label=r"best $\mu$"),
    ]
    fig.legend(handles=handles, loc="upper right", bbox_to_anchor=(0.982, 0.995), ncol=3, frameon=False, title="Observing run")

    for ext in ("pdf", "png", "eps"):
        fig.savefig(OUTDIR / f"fig1_eps15_exclusion_intervals.{ext}", bbox_inches="tight")
    print(f"wrote {OUTDIR / 'fig1_eps15_exclusion_intervals.pdf'}")


if __name__ == "__main__":
    main()
