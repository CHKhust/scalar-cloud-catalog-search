"""Convert cloud-history constraints into event-by-event exclusion intervals.

The input is the per-mu clean-point table from ``postprocess_cloud_history``.
For each event-host branch, this script compares the measured ``Sc/M^2`` upper
limit with a saturated superradiant-cloud model.  The default model is the
Kerr saturation calculation: the final observed black-hole mass is held fixed,
the final spin satisfies Omega_H = omega_R/m, and the initial mass is solved
from energy and angular-momentum conservation between the black hole and the
cloud.  A simpler ``chi_i - chi_crit`` bookkeeping model remains available for
comparison.

The output is an interval table in boson mass for every source whose model
prediction lies above the observational upper limit.  This is a conditional
cloud-history exclusion, not a dark-matter abundance exclusion.
"""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


WORKDIR = Path(__file__).resolve().parent
DEFAULT_PRODUCTS = WORKDIR / "posterior_reweight_catalog/cloud_model/final_cloud_history_eps15_products"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row}) if rows else ["status"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def f(row: dict[str, object], key: str, default: float = math.nan) -> float:
    try:
        return float(row.get(key, default))
    except (TypeError, ValueError):
        return default


def chi_critical(alpha: float, m_level: int = 1, n_level: int = 2) -> float:
    if not np.isfinite(alpha) or alpha <= 0.0:
        return math.nan
    alpha_eff = alpha * (1.0 - alpha * alpha / (2.0 * n_level * n_level))
    if alpha_eff <= 0.0:
        return math.nan
    return float(4.0 * m_level * alpha_eff / (m_level * m_level + 4.0 * alpha_eff * alpha_eff))


def bound_state_energy_factor(alpha: float, n_level: int = 2) -> float:
    """Leading hydrogenic omega_R/mu for a scalar bound state."""

    if not np.isfinite(alpha) or alpha <= 0.0 or n_level <= 0:
        return math.nan
    return 1.0 - alpha * alpha / (2.0 * n_level * n_level)


def kerr_saturated_cloud(
    alpha_final: float,
    chi_i: float,
    m_level: int = 1,
    n_level: int = 2,
) -> dict[str, float | str]:
    """Saturated cloud from Kerr spin-down with energy/angular-momentum balance.

    The measured host mass in the GW posterior is interpreted as the final BH
    mass after the cloud has grown and before the binary inspiral resonance.  Let
    x = M_i/M_f.  The saturation equations are

        Omega_H(chi_f, M_f) = omega_R(alpha_f) / m,
        chi_i x^2 - chi_f = m (x - 1) / (omega_R M_f).

    The returned ``sc_model`` is S_c/M_f^2, matching the normalization used by
    the waveform amplitude parameter.
    """

    if not (np.isfinite(alpha_final) and alpha_final > 0 and np.isfinite(chi_i) and 0 < chi_i < 1):
        return {"status": "invalid", "sc_model": math.nan}
    chi_f = chi_critical(alpha_final, m_level, n_level)
    e_bind = bound_state_energy_factor(alpha_final, n_level)
    omega_mf = alpha_final * e_bind
    if not (np.isfinite(chi_f) and np.isfinite(omega_mf) and omega_mf > 0):
        return {"status": "invalid", "sc_model": math.nan}
    if chi_i <= chi_f:
        return {
            "status": "below_critical",
            "sc_model": 0.0,
            "chi_final": chi_f,
            "omega_m": omega_mf,
            "mass_initial_over_final": 1.0,
            "cloud_mass_fraction_final": 0.0,
            "alpha_initial": alpha_final,
        }

    def balance(x: float) -> float:
        return chi_i * x * x - chi_f - m_level * (x - 1.0) / omega_mf

    lo = 1.0
    hi = 1.0 + 1.0e-6
    # The first root above x=1 is the small-cloud physical branch.
    for _ in range(80):
        if balance(hi) <= 0.0:
            break
        hi = 1.0 + 2.0 * (hi - 1.0)
        if hi > 2.0:
            return {"status": "no_physical_root", "sc_model": math.nan}
    else:
        return {"status": "no_physical_root", "sc_model": math.nan}

    for _ in range(120):
        mid = 0.5 * (lo + hi)
        if balance(mid) > 0.0:
            lo = mid
        else:
            hi = mid
    x = 0.5 * (lo + hi)
    sc_model = m_level * (x - 1.0) / omega_mf
    return {
        "status": "saturated",
        "sc_model": float(sc_model),
        "chi_final": float(chi_f),
        "omega_m": float(omega_mf),
        "mass_initial_over_final": float(x),
        "cloud_mass_fraction_final": float(x - 1.0),
        "alpha_initial": float(alpha_final * x),
    }


def cloud_model_prediction(alpha: float, chi_i: float, args: argparse.Namespace) -> dict[str, float | str]:
    if args.saturation_model == "bookkeeping":
        chi_c = chi_critical(alpha, args.cloud_m, args.cloud_n)
        sc_model = max(0.0, chi_i - chi_c) if np.isfinite(chi_c) else math.nan
        return {
            "status": "bookkeeping",
            "sc_model": sc_model,
            "chi_final": chi_c,
            "omega_m": alpha * bound_state_energy_factor(alpha, args.cloud_n),
            "mass_initial_over_final": 1.0,
            "cloud_mass_fraction_final": math.nan,
            "alpha_initial": alpha,
        }
    return kerr_saturated_cloud(alpha, chi_i, args.cloud_m, args.cloud_n)


def scalar_growth_time_years(alpha: float, m_host_src: float, chi_i: float, state: str) -> float:
    if alpha <= 0 or m_host_src <= 0 or chi_i <= 0:
        return math.nan
    if state == "excited":
        return 1.0e6 / chi_i * (m_host_src / 60.0) * (0.11 / alpha) ** 13
    if state == "ground":
        return 1.0e6 / chi_i * (m_host_src / 60.0) * (0.019 / alpha) ** 9
    raise ValueError(state)


def scalar_cloud_lifetime_years(alpha: float, m_host_src: float, state: str) -> float:
    if alpha <= 0 or m_host_src <= 0:
        return math.nan
    if state == "excited":
        return 1.0e8 * (m_host_src / 60.0) * (0.22 / alpha) ** 20
    if state == "ground":
        return 1.0e8 * (m_host_src / 60.0) * (0.07 / alpha) ** 15
    raise ValueError(state)


def observing_run(event: str, catalog: str = "") -> str:
    try:
        raw = event.removeprefix("GW").split("_")[0]
        year = int(raw[:2])
        month = int(raw[2:4])
        day = int(raw[4:6])
    except Exception:
        return catalog or "unknown"
    year += 2000 if year < 80 else 1900
    ymd = year * 10000 + month * 100 + day
    if 20150912 <= ymd <= 20160119:
        return "O1"
    if 20161130 <= ymd <= 20170825:
        return "O2"
    if 20190401 <= ymd <= 20200327:
        return "O3"
    if 20230524 <= ymd <= 20250630:
        return "O4"
    return catalog or "unknown"


def contiguous_intervals(rows: list[dict[str, object]], gap_factor: float) -> list[list[dict[str, object]]]:
    if not rows:
        return []
    rows = sorted(rows, key=lambda row: f(row, "mu_eV"))
    groups: list[list[dict[str, object]]] = [[rows[0]]]
    prev = f(rows[0], "mu_eV")
    for row in rows[1:]:
        mu = f(row, "mu_eV")
        if prev > 0 and mu / prev <= gap_factor:
            groups[-1].append(row)
        else:
            groups.append([row])
        prev = mu
    return groups


def interval_text(intervals: list[dict[str, object]]) -> str:
    if not intervals:
        return "none"
    parts = []
    for item in intervals:
        lo = float(item["mu_low_eV"])
        hi = float(item["mu_high_eV"])
        if abs(lo - hi) <= 1e-20:
            parts.append(f"{lo:.3e}")
        else:
            parts.append(f"{lo:.3e}-{hi:.3e}")
    return "; ".join(parts)


def model_points(clean_rows: list[dict[str, str]], args: argparse.Namespace) -> list[dict[str, object]]:
    out: list[dict[str, object]] = []
    for row in clean_rows:
        eps_b = f(row, "eps_b")
        if args.eps_values and round(eps_b, 12) not in {round(x, 12) for x in args.eps_values}:
            continue
        if row.get("cloud_model") != "history" or row.get("amplitude_parameter") != "sc":
            continue
        alpha = f(row, "alpha")
        m_host_src = f(row, "m_host_src")
        sc95 = f(row, "sc_95_from_abs_a")
        logb = f(row, "logB_reweighted_resonance_gr")
        valid = f(row, "valid_mapping_fraction", 1.0)
        if not (np.isfinite(sc95) and sc95 > 0 and logb <= args.max_logb and valid >= args.min_valid_fraction):
            continue
        if m_host_src < args.min_bh_host_mass_source:
            continue
        model = cloud_model_prediction(alpha, args.chi_i, args)
        sc_model = f(model, "sc_model")
        chi_c = f(model, "chi_final")
        alpha_growth = f(model, "alpha_initial", alpha)
        if not np.isfinite(alpha_growth) or alpha_growth <= 0.0:
            alpha_growth = alpha
        tau_growth = scalar_growth_time_years(alpha_growth, m_host_src, args.chi_i, args.cloud_state)
        t_cloud = scalar_cloud_lifetime_years(alpha, m_host_src, args.cloud_state)
        growth_before_depletion = bool(np.isfinite(tau_growth) and np.isfinite(t_cloud) and tau_growth < t_cloud)
        growth_within_available = bool(np.isfinite(tau_growth) and tau_growth <= args.available_growth_years)
        survives_delay = bool(np.isfinite(t_cloud) and t_cloud >= args.min_delay_years)
        ratio = sc_model / sc95 if np.isfinite(sc_model) and sc95 > 0 else math.nan
        model_excluded = bool(
            np.isfinite(ratio)
            and ratio >= args.min_ratio
            and growth_before_depletion
            and growth_within_available
            and survives_delay
        )
        out.append(
            {
                "event": row.get("event", ""),
                "rank": row.get("rank", ""),
                "catalog": row.get("catalog", ""),
                "observing_run": row.get("observing_run") or observing_run(row.get("event", ""), row.get("catalog", "")),
                "host": row.get("host", ""),
                "eps_b": eps_b,
                "mu_eV": f(row, "mu_eV"),
                "f_res_hz": f(row, "f_res_hz"),
                "alpha": alpha,
                "m_host_src": m_host_src,
                "q": f(row, "q"),
                "detectors": row.get("detectors", ""),
                "posterior_group": row.get("posterior_group", ""),
                "sc95": sc95,
                "logB": logb,
                "valid_mapping_fraction": valid,
                "chi_i": args.chi_i,
                "saturation_model": args.saturation_model,
                "saturation_status": model.get("status", ""),
                "chi_crit": chi_c,
                "omega_m": f(model, "omega_m"),
                "mass_initial_over_final": f(model, "mass_initial_over_final"),
                "cloud_mass_fraction_final": f(model, "cloud_mass_fraction_final"),
                "alpha_initial_for_growth": alpha_growth,
                "sc_model": sc_model,
                "model_to_limit_ratio": ratio,
                "tau_growth_years": tau_growth,
                "t_cloud_years": t_cloud,
                "growth_before_depletion": growth_before_depletion,
                "growth_within_available": growth_within_available,
                "survives_min_delay": survives_delay,
                "model_excluded": model_excluded,
                "exclusion_status": "excluded_by_model" if model_excluded else "not_excluded_by_model",
            }
        )
    return out


def summarize_sources(points: list[dict[str, object]], args: argparse.Namespace) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    by_key: dict[tuple[str, str, float], list[dict[str, object]]] = {}
    for row in points:
        key = (str(row["event"]), str(row["host"]), round(float(row["eps_b"]), 12))
        by_key.setdefault(key, []).append(row)

    summaries: list[dict[str, object]] = []
    intervals: list[dict[str, object]] = []
    for (event, host, eps_b), rows in sorted(by_key.items(), key=lambda item: (f(item[1][0], "rank"), item[0][0], item[0][1])):
        rows = sorted(rows, key=lambda row: f(row, "mu_eV"))
        selected = [row for row in rows if bool(row["model_excluded"])]
        branch_intervals: list[dict[str, object]] = []
        for idx, group in enumerate(contiguous_intervals(selected, args.gap_factor), start=1):
            best = max(group, key=lambda row: f(row, "model_to_limit_ratio"))
            item = {
                "event": event,
                "rank": rows[0].get("rank", ""),
                "catalog": rows[0].get("catalog", ""),
                "observing_run": rows[0].get("observing_run", ""),
                "host": host,
                "eps_b": eps_b,
                "interval_index": idx,
                "n_points": len(group),
                "mu_low_eV": min(f(row, "mu_eV") for row in group),
                "mu_high_eV": max(f(row, "mu_eV") for row in group),
                "f_low_hz": min(f(row, "f_res_hz") for row in group),
                "f_high_hz": max(f(row, "f_res_hz") for row in group),
                "best_mu_eV": f(best, "mu_eV"),
                "best_f_res_hz": f(best, "f_res_hz"),
                "best_sc95": f(best, "sc95"),
                "best_sc_model": f(best, "sc_model"),
                "best_model_to_limit_ratio": f(best, "model_to_limit_ratio"),
                "detectors": best.get("detectors", ""),
            }
            intervals.append(item)
            branch_intervals.append(item)
        best_row = min(rows, key=lambda row: f(row, "sc95"))
        best_ratio_row = max(rows, key=lambda row: f(row, "model_to_limit_ratio") if np.isfinite(f(row, "model_to_limit_ratio")) else -math.inf)
        summaries.append(
            {
                "event": event,
                "rank": rows[0].get("rank", ""),
                "catalog": rows[0].get("catalog", ""),
                "observing_run": rows[0].get("observing_run", ""),
                "host": host,
                "eps_b": eps_b,
                "n_clean_points": len(rows),
                "n_model_excluded_points": len(selected),
                "n_exclusion_intervals": len(branch_intervals),
                "has_exclusion_interval": bool(branch_intervals),
                "mu_coverage_low_eV": min(f(row, "mu_eV") for row in rows),
                "mu_coverage_high_eV": max(f(row, "mu_eV") for row in rows),
                "excluded_mu_intervals_eV": interval_text(branch_intervals),
                "best_sc95": f(best_row, "sc95"),
                "best_limit_mu_eV": f(best_row, "mu_eV"),
                "best_limit_f_res_hz": f(best_row, "f_res_hz"),
                "best_model_to_limit_ratio": f(best_ratio_row, "model_to_limit_ratio"),
                "best_ratio_mu_eV": f(best_ratio_row, "mu_eV"),
                "best_ratio_f_res_hz": f(best_ratio_row, "f_res_hz"),
                "detectors": best_row.get("detectors", ""),
                "interpretation": "conditional_model_excluded" if branch_intervals else "searched_no_conditional_exclusion",
            }
        )
    return summaries, intervals


def plot_intervals(intervals: list[dict[str, object]], outdir: Path, max_rows: int = 80) -> None:
    if not intervals:
        return
    first_by_source: dict[tuple[str, str], dict[str, object]] = {}
    for row in intervals:
        key = (str(row["event"]), str(row["host"]))
        old = first_by_source.get(key)
        if old is None or f(row, "best_model_to_limit_ratio") > f(old, "best_model_to_limit_ratio"):
            first_by_source[key] = row
    sources = sorted(first_by_source.values(), key=lambda row: -f(row, "best_model_to_limit_ratio"))[:max_rows]
    source_keys = [(str(row["event"]), str(row["host"])) for row in sources]
    y_lookup = {key: idx for idx, key in enumerate(source_keys)}
    fig_h = max(4.5, 0.22 * len(source_keys) + 1.5)
    fig, ax = plt.subplots(figsize=(7.6, fig_h))
    point_seen = False
    interval_seen = False
    for row in intervals:
        key = (str(row["event"]), str(row["host"]))
        if key not in y_lookup:
            continue
        y = y_lookup[key]
        lo = f(row, "mu_low_eV")
        hi = f(row, "mu_high_eV")
        if int(f(row, "n_points", 0)) <= 1 or abs(hi - lo) <= 1e-30:
            ax.plot(
                f(row, "best_mu_eV"),
                y,
                marker="D",
                ms=4.2,
                color="#2f5f8f",
                linestyle="none",
                label="one sampled mass point" if not point_seen else None,
            )
            point_seen = True
        else:
            ax.plot(
                [lo, hi],
                [y, y],
                lw=3.0,
                color="#8b3e2f",
                alpha=0.8,
                solid_capstyle="round",
                label="multi-point interval" if not interval_seen else None,
            )
            ax.plot(f(row, "best_mu_eV"), y, marker="o", ms=3.0, color="#2f5f8f")
            interval_seen = True
    labels = [f"{event} {host}" for event, host in source_keys]
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels, fontsize=7)
    ax.invert_yaxis()
    ax.set_xscale("log")
    ax.set_xlabel(r"Excluded boson mass interval $\mu$ [eV]")
    ax.set_title("Conditional saturated-cloud exclusions by source")
    ax.grid(True, axis="x", which="both", alpha=0.25)
    ax.legend(frameon=False, fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(outdir / "cloud_exclusion_intervals.png", dpi=220)
    fig.savefig(outdir / "cloud_exclusion_intervals.pdf")
    plt.close(fig)


def write_conclusion(path: Path, points: list[dict[str, object]], summaries: list[dict[str, object]], intervals: list[dict[str, object]], args: argparse.Namespace) -> None:
    n_branches = len(summaries)
    n_events = len({row["event"] for row in summaries})
    n_interval_branches = sum(1 for row in summaries if row["has_exclusion_interval"])
    n_interval_events = len({row["event"] for row in summaries if row["has_exclusion_interval"]})
    n_clean_points = len(points)
    max_clean_logb = max((f(row, "logB") for row in points), default=math.nan)
    best = min(points, key=lambda row: f(row, "sc95")) if points else {}
    best_ratio = max(points, key=lambda row: f(row, "model_to_limit_ratio") if np.isfinite(f(row, "model_to_limit_ratio")) else -math.inf) if points else {}
    lines = [
        "Catalog-level scalar-cloud resonance interpretation",
        "",
        f"Model slice: eps_B={','.join(f'{x:g}' for x in args.eps_values) if args.eps_values else 'all'}, "
        f"saturation_model={args.saturation_model}, chi_i={args.chi_i:g}, "
        f"scalar {args.cloud_state} cloud, n={args.cloud_n}, m={args.cloud_m}.",
        f"Growth/survival cuts: tau_growth <= {args.available_growth_years:.2e} yr, "
        f"T_cloud >= {args.min_delay_years:.2e} yr, M_host >= {args.min_bh_host_mass_source:g} Msun.",
        f"Clean data used: {n_clean_points} mu points from {n_branches} event-host branches and {n_events} distinct events.",
        f"Positive-evidence veto: points with logB>{args.max_logb:g} were not used as constraints; maximum retained clean logB is {max_clean_logb:.3g}.",
        "",
        "Main result:",
        f"Under this conditional {args.saturation_model} saturated-cloud model, {n_interval_branches} event-host branches "
        f"({n_interval_events} distinct events) exclude at least one boson-mass interval.",
        f"The strongest direct upper limit is {f(best, 'sc95'):.3e} from {best.get('event','')} "
        f"{best.get('host','')} at mu={f(best, 'mu_eV'):.3e} eV.",
        f"The largest model-to-limit ratio is {f(best_ratio, 'model_to_limit_ratio'):.3e} from "
        f"{best_ratio.get('event','')} {best_ratio.get('host','')} at mu={f(best_ratio, 'mu_eV'):.3e} eV.",
        "",
        "Astronomical wording:",
        "We searched the available public gravitational-wave catalog for the resonant scalar-cloud imprint. "
        "After applying the residual/evidence veto, no source shows a clean and robust detection of the mechanism. "
        "Instead, the results are reported as source-by-source conditional exclusions: wherever the saturated-cloud "
        "model predicts Sc/M^2 above the LIGO posterior-reweighted upper limit, that mass interval is excluded for "
        "that event-host branch.",
        "",
        "Important caveat:",
        "These intervals do not exclude a universal ultralight-dark-matter abundance.  They exclude the existence of "
        "a long-lived saturated cloud around the specified host black hole under the stated growth, survival, and "
        "high-initial-spin assumptions.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")


def write_chinese_conclusion(path: Path, points: list[dict[str, object]], summaries: list[dict[str, object]], intervals: list[dict[str, object]], args: argparse.Namespace) -> None:
    n_branches = len(summaries)
    n_events = len({row["event"] for row in summaries})
    n_interval_branches = sum(1 for row in summaries if row["has_exclusion_interval"])
    n_interval_events = len({row["event"] for row in summaries if row["has_exclusion_interval"]})
    n_clean_points = len(points)
    max_clean_logb = max((f(row, "logB") for row in points), default=math.nan)
    best = min(points, key=lambda row: f(row, "sc95")) if points else {}
    best_ratio = max(points, key=lambda row: f(row, "model_to_limit_ratio") if np.isfinite(f(row, "model_to_limit_ratio")) else -math.inf) if points else {}
    lines = [
        "标量云共振机制的 catalog-level 解释",
        "",
        f"模型切片：eps_B={','.join(f'{x:g}' for x in args.eps_values) if args.eps_values else 'all'}，"
        f"初始自旋 chi_i={args.chi_i:g}，标量 {args.cloud_state} 云，n={args.cloud_n}, m={args.cloud_m}。",
        f"增长/存活条件：tau_growth <= {args.available_growth_years:.2e} yr，"
        f"T_cloud >= {args.min_delay_years:.2e} yr，M_host >= {args.min_bh_host_mass_source:g} Msun。",
        f"实际用于解释的 clean 数据包含 {n_clean_points} 个质量点，来自 {n_branches} 个 event-host 分支和 {n_events} 个不同事件。",
        f"所有 logB>{args.max_logb:g} 的点都作为 residual/systematics veto 排除；保留下来的 clean 点最大 logB 为 {max_clean_logb:.3g}。",
        "",
        "主要结论：",
        f"在这个有条件的饱和长寿命标量云模型下，{n_interval_branches} 个 event-host 分支"
        f"（{n_interval_events} 个不同事件）给出了至少一个玻色子质量排除区间。",
        f"最强的直接上限来自 {best.get('event','')} {best.get('host','')}："
        f"Sc/M^2 < {f(best, 'sc95'):.3e}，mu={f(best, 'mu_eV'):.3e} eV。",
        f"最大的理论/观测比值来自 {best_ratio.get('event','')} {best_ratio.get('host','')}："
        f"Sc_model/Sc95={f(best_ratio, 'model_to_limit_ratio'):.3e}，mu={f(best_ratio, 'mu_eV'):.3e} eV。",
        "",
        "建议的天文学表述：",
        "我们从公开引力波事件表出发，对满足黑洞宿主、频带覆盖和数据质量要求的事件进行了标量云共振印记搜索。"
        "在采用 residual/evidence veto 后，没有发现任何源给出清晰、稳健的该机制正证据。"
        "因此结果应表述为逐源的条件排除：当饱和长寿命标量云模型预言的 Sc/M^2 高于 LIGO posterior-reweighted 上限时，"
        "对应的玻色子质量区间在该 event-host 分支下被排除。",
        "",
        "重要限制：",
        "这些区间不是通用 ultralight dark matter 丰度排除曲线。它们排除的是：在高初始自旋、云已增长饱和且能存活到 inspiral 的假设下，"
        "指定黑洞宿主周围存在这种长寿命饱和云的可能性。",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--clean-csv", type=Path, default=DEFAULT_PRODUCTS / "cloud_history_all_clean_mu_points.csv")
    parser.add_argument("--outdir", type=Path, default=WORKDIR / "posterior_reweight_catalog/cloud_model/cloud_exclusion_intervals_eps15")
    parser.add_argument("--eps-values", nargs="*", type=float, default=[15.0])
    parser.add_argument("--chi-i", type=float, default=0.9)
    parser.add_argument(
        "--saturation-model",
        choices=["detailed", "bookkeeping"],
        default="detailed",
        help="detailed solves Kerr saturation with energy/angular-momentum conservation; bookkeeping uses chi_i-chi_crit.",
    )
    parser.add_argument("--cloud-state", choices=["ground", "excited"], default="excited")
    parser.add_argument("--cloud-m", type=int, default=1)
    parser.add_argument("--cloud-n", type=int, default=2)
    parser.add_argument("--available-growth-years", type=float, default=1.0e6)
    parser.add_argument("--min-delay-years", type=float, default=1.0e8)
    parser.add_argument("--min-bh-host-mass-source", type=float, default=3.0)
    parser.add_argument("--min-ratio", type=float, default=1.0)
    parser.add_argument("--max-logb", type=float, default=3.0)
    parser.add_argument("--min-valid-fraction", type=float, default=0.5)
    parser.add_argument("--gap-factor", type=float, default=1.25)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    clean = read_csv(args.clean_csv)
    args.outdir.mkdir(parents=True, exist_ok=True)
    points = model_points(clean, args)
    summaries, intervals = summarize_sources(points, args)
    write_csv(args.outdir / "cloud_model_points.csv", points)
    write_csv(args.outdir / "cloud_exclusion_source_summary.csv", summaries)
    write_csv(args.outdir / "cloud_exclusion_intervals_by_source.csv", intervals)
    plot_intervals(intervals, args.outdir)
    write_conclusion(args.outdir / "cloud_exclusion_catalog_conclusion.txt", points, summaries, intervals, args)
    write_chinese_conclusion(args.outdir / "cloud_exclusion_catalog_conclusion_zh.txt", points, summaries, intervals, args)
    print(f"model_points={len(points)}")
    print(f"source_branches={len(summaries)}")
    print(f"interval_rows={len(intervals)}")
    print(f"branches_with_intervals={sum(1 for row in summaries if row['has_exclusion_interval'])}")
    print(f"wrote {args.outdir}")


if __name__ == "__main__":
    main()
