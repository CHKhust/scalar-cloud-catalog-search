from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D


ROOT = Path(__file__).resolve().parent
FIGDIR = ROOT / "apjl_scalar_cloud_resonance" / "figures"
TOP15 = ROOT / "analysis_outputs" / "eps5_eps15_catalog" / "eps15_top_direct_limits.csv"
TOP5 = ROOT / "analysis_outputs" / "eps5_eps15_catalog" / "eps5_top_direct_limits.csv"
NS800_DIRECT_CANDIDATES = [
    ROOT / "analysis_outputs" / "eps15_ns800_final_20260608_175421" / "eps15_ns800_direct_summary.csv",
    ROOT / "analysis_outputs" / "eps15_ns800_followup_analysis" / "eps15_ns800_direct_summary.csv",
]

RUN_COLORS = {
    "O1": "#7B61D1",
    "O2": "#63A95D",
    "O3": "#087C83",
    "O4": "#E1661A",
    "GWTC-4.1": "#E1661A",
    "GWTC-5.0": "#E1661A",
}


def setup() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "DejaVu Sans"],
            "mathtext.fontset": "stixsans",
            "axes.linewidth": 0.8,
            "axes.titlesize": 9.0,
            "axes.labelsize": 8.5,
            "xtick.labelsize": 7.6,
            "ytick.labelsize": 7.4,
            "legend.fontsize": 7.0,
            "figure.dpi": 180,
            "savefig.dpi": 420,
        }
    )


def run_color(run: str) -> str:
    run = str(run)
    if run in RUN_COLORS:
        return RUN_COLORS[run]
    if "O4" in run or "GWTC-4" in run or "GWTC-5" in run:
        return RUN_COLORS["O4"]
    if "O3" in run:
        return RUN_COLORS["O3"]
    if "O2" in run:
        return RUN_COLORS["O2"]
    if "O1" in run:
        return RUN_COLORS["O1"]
    return "#6B7280"


def host_math(host: str) -> str:
    host = str(host)
    if host.startswith("m") and host[1:].isdigit():
        return rf"$m_{{{host[1:]}}}$"
    return host


def main() -> None:
    setup()
    FIGDIR.mkdir(parents=True, exist_ok=True)
    ns800_direct = next((p for p in NS800_DIRECT_CANDIDATES if p.exists()), None)
    if ns800_direct is not None:
        top15 = pd.read_csv(ns800_direct).rename(
            columns={
                "best_sc95_ns800": "best_sc95",
                "best_mu_eV_ns800": "mu_eV",
                "best_f_res_hz_ns800": "f_res_hz",
            }
        ).sort_values("best_sc95")
        top15["observing_run"] = top15["event"].map(lambda e: "O4" if str(e).startswith(("GW23", "GW24", "GW25")) else ("O2" if str(e).startswith("GW17") else "O3"))
    else:
        top15 = pd.read_csv(TOP15)
    top = top15.head(10).copy().iloc[::-1]

    fig = plt.figure(figsize=(7.15, 5.0), constrained_layout=True)
    gs = fig.add_gridspec(2, 1, height_ratios=[0.82, 1.55], hspace=0.12)
    ax = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[1, 0])

    eps = [15, 5]
    usable = np.array([3822, 3456])
    residual = np.array([420, 371])
    mapping = np.array([5, 54])
    y = np.arange(len(eps))

    ax.barh(y, usable, color="#2F5F8F", height=0.46, label="usable limits")
    ax.barh(y, residual, left=usable, color="#B95D42", height=0.46, label=r"searched, $\ln B>3$")
    ax.barh(y, mapping, left=usable + residual, color="#9CA3AF", height=0.46, label="nonphysical mapping")
    ax.set_yticks(y, [r"$\epsilon_B=15$", r"$\epsilon_B=5$"])
    ax.invert_yaxis()
    ax.set_xlim(0, 5050)
    ax.set_xlabel("mass points")
    ax.set_title("(a) Catalog accounting", loc="left")
    ax.grid(axis="x", color="#E5E7EB", lw=0.6)
    ax.spines[["top", "right"]].set_visible(False)

    notes = [
        "72 events, 36 high-resolution intervals",
        "direct limits only, no long-lived intervals",
    ]
    for yi, u, r, m, note in zip(y, usable, residual, mapping, notes):
        ax.text(u * 0.50, yi, f"usable {int(u)}", ha="center", va="center", fontsize=7.0, color="white")
        ax.text(u + r * 0.50, yi, f"$\\ln B>3$ {int(r)}", ha="center", va="center", fontsize=6.6, color="white")
        if m > 20:
            ax.text(u + r + m + 32, yi - 0.18, f"mapping {int(m)}", ha="left", va="center", fontsize=6.8, color="#64748B")
        ax.text(u + r + m + 135, yi, note, va="center", ha="left", fontsize=7.0, color="#334155")

    labels = [f"{e} {host_math(h)}" for e, h in zip(top["event"], top["host"])]
    y2 = np.arange(len(top))
    colors = [run_color(r) for r in top["observing_run"]]
    ax2.hlines(y2, xmin=3.9e-3, xmax=top["best_sc95"], color="#D8DEE9", lw=1.3)
    ax2.scatter(top["best_sc95"], y2, s=36, color=colors, edgecolor="#111827", linewidth=0.35, zorder=3)
    ax2.set_xscale("log")
    ax2.set_xlim(3.9e-3, 2.2e-2)
    ax2.set_yticks(y2, labels)
    ax2.set_xlabel(r"best direct $(S_c/M^2)_{95}$")
    ax2.set_title(r"(b) Tightest direct limits, $\epsilon_B=15$", loc="left")
    ax2.grid(axis="x", color="#E5E7EB", lw=0.6)
    ax2.spines[["top", "right"]].set_visible(False)

    handles = [
        Line2D([0], [0], marker="o", lw=0, markerfacecolor=RUN_COLORS["O3"], markeredgecolor="#111827", markersize=5, label="O3"),
        Line2D([0], [0], marker="o", lw=0, markerfacecolor=RUN_COLORS["O4"], markeredgecolor="#111827", markersize=5, label="O4"),
    ]
    ax2.legend(handles=handles, loc="upper right", frameon=False, title="observing run")

    for ext in ("pdf", "png", "eps"):
        fig.savefig(FIGDIR / f"fig2_catalog_summary_top_limits.{ext}", bbox_inches="tight")
    print(f"wrote {FIGDIR / 'fig2_catalog_summary_top_limits.pdf'}")


if __name__ == "__main__":
    main()
