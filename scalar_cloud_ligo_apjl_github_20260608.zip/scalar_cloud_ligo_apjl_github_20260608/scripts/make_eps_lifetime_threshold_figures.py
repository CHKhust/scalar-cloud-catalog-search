"""Make side-by-side lifetime-threshold diagnostics for eps=15 and eps=5.

This script reads already postprocessed catalog products only.  It does not
touch LIGO strain/posterior files and does not modify the manuscript.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.ticker import FixedFormatter, FixedLocator, NullFormatter
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "analysis_outputs" / "eps5_eps15_catalog"
FIGDIR = ROOT / "apjl_scalar_cloud_resonance" / "figures"
EPS5_POINTS = (
    ROOT
    / "hpc_downloads"
    / "eps5_results"
    / "posterior_reweight_catalog"
    / "cloud_model"
    / "cloud_exclusion_intervals_eps5_detailed"
    / "cloud_model_points.csv"
)


def find_prl_root() -> Path:
    for path in Path("G:/").iterdir():
        if path.is_dir() and path.name.startswith("PRL"):
            return path
    raise FileNotFoundError("Could not find G:/PRL* result directory")


def load_points() -> dict[int, pd.DataFrame]:
    eps15 = find_prl_root() / "cloud_exclusion_intervals_eps15_detailed" / "cloud_model_points.csv"
    data = {
        15: pd.read_csv(eps15),
        5: pd.read_csv(EPS5_POINTS),
    }
    for eps, df in data.items():
        needed = {"mu_eV", "t_cloud_years", "model_to_limit_ratio", "model_excluded", "event", "host"}
        missing = sorted(needed - set(df.columns))
        if missing:
            raise ValueError(f"eps={eps} missing columns: {missing}")
        df["log10_ratio"] = pd.NA
        positive = df["model_to_limit_ratio"] > 0
        df.loc[positive, "log10_ratio"] = df.loc[positive, "model_to_limit_ratio"].map(lambda x: float(np.log10(x)))
        df["mu_12"] = df["mu_eV"] / 1e-12
    return data


def branch_count(df: pd.DataFrame) -> int:
    if df.empty:
        return 0
    return df[["event", "host"]].drop_duplicates().shape[0]


def threshold_table(data: dict[int, pd.DataFrame]) -> pd.DataFrame:
    rows = []
    for eps, df in data.items():
        ratio = df[df["model_to_limit_ratio"] > 1].copy()
        for tcut in [1e5, 1e6, 1e7, 1e8]:
            keep = ratio[ratio["t_cloud_years"] >= tcut]
            rows.append(
                {
                    "eps_b": eps,
                    "t_cloud_cut_years": tcut,
                    "ratio_gt_1_points_surviving": len(keep),
                    "ratio_gt_1_branches_surviving": branch_count(keep),
                    "ratio_gt_1_events_surviving": keep["event"].nunique() if len(keep) else 0,
                }
            )
        excluded = df[df["model_excluded"].astype(str).str.lower().eq("true")]
        rows.append(
            {
                "eps_b": eps,
                "t_cloud_cut_years": "model_excluded_current",
                "ratio_gt_1_points_surviving": len(excluded),
                "ratio_gt_1_branches_surviving": branch_count(excluded),
                "ratio_gt_1_events_surviving": excluded["event"].nunique() if len(excluded) else 0,
            }
        )
    return pd.DataFrame(rows)


def style_axes(ax: plt.Axes) -> None:
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.grid(True, which="major", color="#d4d4d8", lw=0.55, alpha=0.8)
    ax.grid(True, which="minor", color="#e5e7eb", lw=0.35, alpha=0.45)
    ax.tick_params(direction="in", top=True, right=True, which="both", length=3.0)
    ax.set_xlabel(r"boson mass $\mu$ [eV]")
    ax.set_ylabel(r"cloud lifetime $T_{\rm cloud}$ [yr]")
    for tcut, color, lw in [(1e6, "#64748b", 0.8), (1e7, "#64748b", 0.8), (1e8, "#111827", 1.2)]:
        ax.axhline(tcut, color=color, ls="--", lw=lw, zorder=1)
    ax.text(
        0.97,
        1.14e8,
        r"$10^8$ yr",
        ha="right",
        va="bottom",
        transform=ax.get_yaxis_transform(),
        fontsize=8,
        color="#111827",
    )


def panel(ax: plt.Axes, df: pd.DataFrame, eps: int, norm: Normalize, cmap: str = "viridis") -> None:
    clean = df.copy()
    ratio = clean[clean["model_to_limit_ratio"] > 1].copy()
    excluded = clean[clean["model_excluded"].astype(str).str.lower().eq("true")].copy()

    ax.scatter(
        clean["mu_12"],
        clean["t_cloud_years"],
        s=7,
        color="#d1d5db",
        alpha=0.45,
        linewidths=0,
        rasterized=True,
        label="clean model points",
    )
    if len(ratio):
        sc = ax.scatter(
            ratio["mu_12"],
            ratio["t_cloud_years"],
            c=ratio["log10_ratio"].astype(float),
            s=13,
            cmap=cmap,
            norm=norm,
            alpha=0.85,
            linewidths=0,
            rasterized=True,
            label=r"$S_{c,\rm model}/S_{c,95}>1$",
        )
    else:
        sc = None
    if len(excluded):
        ax.scatter(
            excluded["mu_12"],
            excluded["t_cloud_years"],
            s=24,
            facecolors="none",
            edgecolors="#111827",
            linewidths=0.75,
            label=r"excluded at $10^8$ yr",
        )

    style_axes(ax)
    ax.set_title(rf"$\epsilon_B={eps}$", fontsize=11)
    ax.set_xlabel(r"boson mass $\mu$ [$10^{-12}$ eV]")
    ax.set_xlim(1.45, 13.5)
    ax.set_ylim(7e2, 5e9)
    ax.xaxis.set_major_locator(FixedLocator([2, 3, 5, 8, 12]))
    ax.xaxis.set_major_formatter(FixedFormatter(["2", "3", "5", "8", "12"]))
    ax.xaxis.set_minor_formatter(NullFormatter())

    return sc


def make_figures(data: dict[int, pd.DataFrame]) -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "Times", "Nimbus Roman", "DejaVu Serif"],
            "mathtext.fontset": "stix",
            "axes.linewidth": 0.8,
            "axes.labelsize": 9,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "legend.fontsize": 8,
            "savefig.bbox": "tight",
        }
    )
    OUT.mkdir(parents=True, exist_ok=True)
    FIGDIR.mkdir(parents=True, exist_ok=True)

    all_ratio = pd.concat([df[df["model_to_limit_ratio"] > 1] for df in data.values()], ignore_index=True)
    vmax = max(0.2, min(2.0, float(all_ratio["log10_ratio"].astype(float).quantile(0.995))))
    norm = Normalize(vmin=0.0, vmax=vmax)

    for eps in [15, 5]:
        fig, ax = plt.subplots(figsize=(3.45, 3.05))
        sc = panel(ax, data[eps], eps, norm)
        if sc is not None:
            cbar = fig.colorbar(sc, ax=ax, pad=0.02, fraction=0.055)
            cbar.set_label(r"$\log_{10}(S_{c,\rm model}/S_{c,95})$")
        fig.savefig(OUT / f"eps{eps}_lifetime_threshold_diagnostic.png", dpi=350)
        fig.savefig(OUT / f"eps{eps}_lifetime_threshold_diagnostic.pdf")
        fig.savefig(OUT / f"eps{eps}_lifetime_threshold_diagnostic.eps")
        plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(7.05, 3.15), sharex=True, sharey=True)
    sc = None
    for ax, eps in zip(axes, [15, 5]):
        sc = panel(ax, data[eps], eps, norm)
    axes[1].set_ylabel("")
    if sc is not None:
        cbar = fig.colorbar(sc, ax=axes.ravel().tolist(), pad=0.015, fraction=0.04)
        cbar.set_label(r"$\log_{10}(S_{c,\rm model}/S_{c,95})$")
    for ext in ("png", "pdf", "eps"):
        kwargs = {"dpi": 350} if ext == "png" else {}
        fig.savefig(OUT / f"eps15_eps5_lifetime_threshold_side_by_side.{ext}", **kwargs)
        fig.savefig(FIGDIR / f"fig4_eps15_eps5_lifetime_threshold_side_by_side.{ext}", **kwargs)
    plt.close(fig)


def main() -> None:
    data = load_points()
    table = threshold_table(data)
    OUT.mkdir(parents=True, exist_ok=True)
    table.to_csv(OUT / "eps15_eps5_survival_threshold_counts.csv", index=False)
    make_figures(data)
    print(table.to_string(index=False))
    print(f"Wrote figures and table to {OUT}")


if __name__ == "__main__":
    main()
