#!/usr/bin/env bash
set -eo pipefail

cd ~/scalar_cloud_ligo
mkdir -p logs

MODE="${1:-all}"
WINDOW="${WINDOW:-4}"

ROOT="$PWD/eps15_followup_resume_campaigns"
RUNNER="$ROOT/slurm_array_run4.sh"

run_campaign () {
  local NAME="$1"
  local DIR="$2"

  local N
  N=$(find "$DIR" -maxdepth 1 -name 'job_*.sh' | wc -l)

  echo "=== campaign: $NAME ==="
  echo "DIR=$DIR"
  echo "N=$N"
  echo "WINDOW=$WINDOW"

  local START=1
  while [ "$START" -le "$N" ]; do
    local END=$((START + WINDOW - 1))
    if [ "$END" -gt "$N" ]; then
      END="$N"
    fi

    echo "Submitting $NAME array ${START}-${END}%${WINDOW} at $(date)"

    JID=$(sbatch --parsable \
      --export=ALL,BATCH_DIR="$DIR" \
      --array=${START}-${END}%${WINDOW} \
      "$RUNNER")

    echo "Submitted job $JID"

    while squeue -h -j "$JID" | grep -q .; do
      echo "Waiting for $JID at $(date)"
      squeue -j "$JID" || true
      sleep 90
    done

    echo "Finished $JID at $(date)"
    START=$((END + 1))
  done

  echo "=== campaign done: $NAME $(date) ==="
}

chmod +x "$ROOT"/*.sh "$ROOT"/all_exclusion_ns800/*.sh "$ROOT"/confirmed_interval_narrow_ns800/*.sh

case "$MODE" in
  all)
    run_campaign "all_exclusion_ns800" "$ROOT/all_exclusion_ns800"
    ;;
  narrow)
    run_campaign "confirmed_interval_narrow_ns800" "$ROOT/confirmed_interval_narrow_ns800"
    ;;
  both)
    run_campaign "all_exclusion_ns800" "$ROOT/all_exclusion_ns800"
    run_campaign "confirmed_interval_narrow_ns800" "$ROOT/confirmed_interval_narrow_ns800"
    ;;
  *)
    echo "usage: bash $0 [all|narrow|both]"
    exit 2
    ;;
esac
