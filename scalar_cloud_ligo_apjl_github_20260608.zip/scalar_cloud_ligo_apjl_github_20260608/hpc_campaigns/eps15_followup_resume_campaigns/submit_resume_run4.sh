#!/usr/bin/env bash
set -eo pipefail

cd ~/scalar_cloud_ligo
mkdir -p logs

ROOT="$PWD/eps15_followup_resume_campaigns"
ALL_DIR="$ROOT/all_exclusion_ns800"
NARROW_DIR="$ROOT/confirmed_interval_narrow_ns800"
RUNNER="$ROOT/slurm_array_run4.sh"

chmod +x "$ROOT"/*.sh "$ALL_DIR"/*.sh "$NARROW_DIR"/*.sh

N_ALL=$(find "$ALL_DIR" -maxdepth 1 -name 'job_*.sh' | wc -l)
N_NARROW=$(find "$NARROW_DIR" -maxdepth 1 -name 'job_*.sh' | wc -l)

case "${1:-all}" in
  all)
    sbatch --export=ALL,BATCH_DIR="$ALL_DIR" --array=1-${N_ALL}%4 "$RUNNER"
    ;;
  narrow)
    sbatch --export=ALL,BATCH_DIR="$NARROW_DIR" --array=1-${N_NARROW}%4 "$RUNNER"
    ;;
  both)
    sbatch --export=ALL,BATCH_DIR="$ALL_DIR" --array=1-${N_ALL}%4 "$RUNNER"
    sbatch --export=ALL,BATCH_DIR="$NARROW_DIR" --array=1-${N_NARROW}%4 "$RUNNER"
    ;;
  *)
    echo "usage: bash $0 [all|narrow|both]" >&2
    exit 2
    ;;
esac

squeue -u "$USER"
