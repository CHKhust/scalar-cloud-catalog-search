#!/usr/bin/env bash
#SBATCH --job-name=cloud_n800all_2
#SBATCH --partition=cpu-pgmf
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --time=08:00:00
#SBATCH --comment=public_cluster
#SBATCH -o logs/cloud_n800all_2_%j.out
#SBATCH -e logs/cloud_n800all_2_%j.err

set -eo pipefail
source ~/miniforge3/etc/profile.d/conda.sh
conda activate ligo-lal
set -u

cd '/home/ud202280025/scalar_cloud_ligo'
mkdir -p logs

export LIGO_DATA_ROOT='/home/ud202280025/LIGO_data_upload'
export LIGO_POSTERIOR_DIR="$LIGO_DATA_ROOT/posterior_data"
export LIGO_STRAIN_DIR="$LIGO_DATA_ROOT/strain_data"

if [ ! -d "$LIGO_POSTERIOR_DIR" ] || [ ! -d "$LIGO_STRAIN_DIR" ]; then
  echo "ERROR missing LIGO data directories under $LIGO_DATA_ROOT" >&2
  exit 2
fi

echo "JOB_NAME=cloud_n800all"
echo "JOB_INDEX=2"
echo "HOST=$(hostname)"
echo "DATE_START=$(date)"

echo "START all_exclusion_ns800_GW200115_042309_m1_C01_IMRPhenomXPHM_LowSpin_H1-L1-V1_Nmu31_Ns800 $(date)"
python - <<'PY'
import glob
import sys
pattern = "posterior_reweight_catalog/mu_grid/GW200115_042309_m1_*C01*IMRPhenomXPHM*LowSpin*IMRPhenomD*history_sc_spa*H1-L1-V1*Nmu31_Ns800.csv"
matches = glob.glob(pattern)
if matches:
    print("SKIP existing", matches[0])
    sys.exit(0)
PY
python catalog_mu_grid_scan.py \
  --rank 2 \
  --host m1 \
  --posterior-group 'C01:IMRPhenomXPHM:LowSpin' \
  --eps-b 15 \
  --f-grid-min 26.9872531 \
  --f-grid-max 39.55953023 \
  --n-mu 31 \
  --max-samples 800 \
  --n-a 61 \
  --duration 32 \
  --minimum-frequency 20 \
  --maximum-frequency 512 \
  --approximant 'IMRPhenomD' \
  --morphology ramp \
  --width-hz 4 \
  --width-mode literature \
  --cloud-model history \
  --amplitude-mode coherent-profile \
  --amplitude-parameter sc \
  --backreaction-amplitude spa \
  --sc-max 0.02 \
  --sample-dependent-mapping \
  --progress 50 \
  --detectors H1 L1 V1
echo "END all_exclusion_ns800_GW200115_042309_m1_C01_IMRPhenomXPHM_LowSpin_H1-L1-V1_Nmu31_Ns800 $(date)"

echo "JOB_DONE $(date)"
