#!/usr/bin/env bash
set -eo pipefail
cd ~/scalar_cloud_ligo
echo "=== queue ==="
squeue -u "$USER" -n cloud_narrow_1,cloud_narrow_2,cloud_narrow_3,cloud_narrow_4,cloud_narrow_5,cloud_narrow_6 -o "%.18i %.22j %.10T %.10M %.6D %R" || true
echo "=== starts/ends ==="
grep -R "^START\|^END\|JOB_DONE\|ERROR\|Traceback\|SKIP existing" logs/cloud_narrow_*.out logs/cloud_narrow_*.err 2>/dev/null || true
echo "=== csv outputs ==="
find posterior_reweight_catalog/mu_grid -name "*history_sc_spa*Nmu*Ns*.csv" | wc -l
