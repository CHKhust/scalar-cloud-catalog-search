#!/usr/bin/env bash
#SBATCH --job-name=cloud_narrow_3
#SBATCH --partition=cpu-pgmf
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --time=08:00:00
#SBATCH --comment=public_cluster
#SBATCH -o logs/cloud_narrow_3_%j.out
#SBATCH -e logs/cloud_narrow_3_%j.err

set -eo pipefail
source ~/miniforge3/etc/profile.d/conda.sh
conda activate ligo-lal
set -u

cd '/home/ud202280025/scalar_cloud_ligo'
mkdir -p logs

export LIGO_DATA_ROOT='/home/ud202280025/LIGO_data_upload'
export LIGO_POSTERIOR_DIR="$LIGO_DATA_ROOT/posterior_data"
export LIGO_STRAIN_DIR="$LIGO_DATA_ROOT/strain_data"

if [ ! -d "$LIGO_POSTERIOR_DIR" ] || [ ! -d "$LIGO_STRAIN_DIR" ]; then
  echo "ERROR missing LIGO data directories under $LIGO_DATA_ROOT" >&2
  exit 2
fi

echo "JOB_NAME=cloud_narrow"
echo "JOB_INDEX=3"
echo "HOST=$(hostname)"
echo "DATE_START=$(date)"

echo "START confirmed_interval_narrow_ns800_GW230627_015337_m1_C00_IMRPhenomXPHM-SpinTaylor_H1-L1_Nmu151_Ns800 $(date)"
python - <<'PY'
import glob
import sys
pattern = "posterior_reweight_catalog/mu_grid/GW230627_015337_m1_*C00*IMRPhenomXPHM-SpinTaylor*IMRPhenomD*history_sc_spa*H1-L1*Nmu151_Ns800.csv"
matches = glob.glob(pattern)
if matches:
    print("SKIP existing", matches[0])
    sys.exit(0)
PY
python catalog_mu_grid_scan.py \
  --rank 5 \
  --host m1 \
  --posterior-group 'C00:IMRPhenomXPHM-SpinTaylor' \
  --eps-b 15 \
  --f-grid-min 24.17923146 \
  --f-grid-max 28.5777793 \
  --n-mu 151 \
  --max-samples 800 \
  --n-a 61 \
  --duration 32 \
  --minimum-frequency 20 \
  --maximum-frequency 512 \
  --approximant 'IMRPhenomD' \
  --morphology ramp \
  --width-hz 4 \
  --width-mode literature \
  --cloud-model history \
  --amplitude-mode coherent-profile \
  --amplitude-parameter sc \
  --backreaction-amplitude spa \
  --sc-max 0.02 \
  --sample-dependent-mapping \
  --progress 50 \
  --detectors H1 L1
echo "END confirmed_interval_narrow_ns800_GW230627_015337_m1_C00_IMRPhenomXPHM-SpinTaylor_H1-L1_Nmu151_Ns800 $(date)"

echo "JOB_DONE $(date)"
