#!/usr/bin/env bash
# Generic Slurm array runner for eps=15 resume follow-ups.
# Submit with:
#   sbatch --export=ALL,BATCH_DIR=/path/to/campaign --array=1-N%4 slurm_array_run4.sh
# where campaign contains job_001.sh ... job_NNN.sh.
#SBATCH --job-name=eps15_res
#SBATCH --partition=cpu-pgmf
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --time=08:00:00
#SBATCH --comment=public_cluster
#SBATCH -o logs/eps15_res_%A_%a.out
#SBATCH -e logs/eps15_res_%A_%a.err

set -eo pipefail

source ~/miniforge3/etc/profile.d/conda.sh
conda activate ligo-lal
set -u

cd ~/scalar_cloud_ligo
mkdir -p logs

echo "HOST=$(hostname)"
echo "DATE=$(date)"
echo "TASK=${SLURM_ARRAY_TASK_ID}"
echo "BATCH_DIR=${BATCH_DIR}"

JOB_SCRIPT=$(printf "%s/job_%03d.sh" "$BATCH_DIR" "$SLURM_ARRAY_TASK_ID")
echo "Running $JOB_SCRIPT"
ls -lh "$JOB_SCRIPT"

bash "$JOB_SCRIPT"

echo "DONE $(date)"
