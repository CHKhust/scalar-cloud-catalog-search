#!/usr/bin/env bash
set -eo pipefail

cd ~/scalar_cloud_ligo

echo "=== queue ==="
squeue -u "$USER" || true

echo "=== new resume starts/ends ==="
grep -R "^START\|^END\|JOB_DONE\|DONE\|SKIP existing\|Traceback\|ERROR\|TIME LIMIT" logs/eps15_res_*.out logs/eps15_res_*.err 2>/dev/null || true

echo "=== counts ==="
printf "START: "
grep -R "^START" logs/eps15_res_*.out 2>/dev/null | wc -l || true
printf "END:   "
grep -R "^END" logs/eps15_res_*.out 2>/dev/null | wc -l || true
printf "DONE:  "
grep -R "^DONE\|JOB_DONE" logs/eps15_res_*.out 2>/dev/null | wc -l || true
printf "Nmu31 Ns800 csv:  "
find posterior_reweight_catalog/mu_grid -name "*Nmu31_Ns800.csv" | wc -l
printf "Nmu151 Ns800 csv: "
find posterior_reweight_catalog/mu_grid -name "*Nmu151_Ns800.csv" | wc -l
