#!/usr/bin/env bash
#SBATCH --job-name=gw230518_val
#SBATCH --partition=cpu-pgmf
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --time=08:00:00
#SBATCH --comment=public_cluster
#SBATCH -o logs/gw230518_val_%A_%a.out
#SBATCH -e logs/gw230518_val_%A_%a.err

set -eo pipefail

source ~/miniforge3/etc/profile.d/conda.sh
conda activate ligo-lal
set -u

cd ~/scalar_cloud_ligo
mkdir -p logs posterior_reweight_catalog/validation_gw230518

export LIGO_DATA_ROOT=/home/ud202280025/LIGO_data_upload
export LIGO_POSTERIOR_DIR="$LIGO_DATA_ROOT/posterior_data"
export LIGO_STRAIN_DIR="$LIGO_DATA_ROOT/strain_data"

case "${SLURM_ARRAY_TASK_ID}" in
  1)
    LABEL="H1_only"
    DETS="H1"
    ;;
  2)
    LABEL="L1_only"
    DETS="L1"
    ;;
  3)
    LABEL="H1_L1"
    DETS="H1 L1"
    ;;
  4)
    LABEL="H1_L1_notch44"
    DETS="H1 L1"
    NOTCH="--notch L1:42:46"
    ;;
  5)
    LABEL="H1_L1_Ns800_mu101"
    DETS="H1 L1"
    HIGHRES=1
    ;;
  *)
    echo "Unknown task ${SLURM_ARRAY_TASK_ID}" >&2
    exit 2
    ;;
esac

NOTCH="${NOTCH:-}"
HIGHRES="${HIGHRES:-0}"

echo "LABEL=$LABEL"
echo "DETS=$DETS"
echo "DATE=$(date)"

if [ "$HIGHRES" = "1" ]; then
  python catalog_mu_grid_scan.py \
    --rank 1 \
    --host m1 \
    --posterior-group 'C00:IMRPhenomXPHM-SpinTaylor' \
    --eps-b 15 \
    --f-grid-min 27.4 \
    --f-grid-max 32.3 \
    --n-mu 101 \
    --max-samples 800 \
    --n-a 61 \
    --duration 32 \
    --minimum-frequency 20 \
    --maximum-frequency 512 \
    --approximant IMRPhenomD \
    --morphology ramp \
    --width-hz 4 \
    --width-mode literature \
    --cloud-model history \
    --amplitude-mode coherent-profile \
    --amplitude-parameter sc \
    --backreaction-amplitude spa \
    --sc-max 0.02 \
    --sample-dependent-mapping \
    --detectors $DETS \
    --progress 50
else
  python diagnose_detector_veto.py \
    --rank 1 \
    --posterior-group 'C00:IMRPhenomXPHM-SpinTaylor' \
    --detectors $DETS \
    $NOTCH \
    --max-samples 800 \
    --duration 32 \
    --minimum-frequency 20 \
    --maximum-frequency 512 \
    --approximant IMRPhenomD \
    --morphology ramp \
    --width-hz 4 \
    --amplitude-mode coherent-profile \
    --a-max 6 \
    --n-a 61 \
    --n-f 41 \
    --f-center 44 \
    --f-span 20 \
    --use-posterior-detector-times \
    | tee "posterior_reweight_catalog/validation_gw230518/${LABEL}_detector_veto.txt"
fi

echo "DONE $(date)"
