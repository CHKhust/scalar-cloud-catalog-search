#!/usr/bin/env bash
set -eo pipefail

cd ~/scalar_cloud_ligo

echo "=== queue ==="
squeue -u "$USER" || true

echo "=== validation logs ==="
grep -R "LABEL=\|DONE\|Traceback\|RuntimeError\|ERROR\|logB\|sc_95\|detectors" \
  logs/gw230518_val_*.out logs/gw230518_val_*.err 2>/dev/null || true

echo "=== output files ==="
find posterior_reweight_catalog/validation_gw230518 posterior_reweight_catalog/mu_grid \
  -maxdepth 2 \( -name "*GW230518*Nmu101_Ns800*.csv" -o -name "*detector_veto.txt" \) \
  -print 2>/dev/null || true
