#!/usr/bin/env bash
set -eo pipefail

cd ~/scalar_cloud_ligo
mkdir -p logs
chmod +x gw230518_validation_campaign/*.sh

# Five lightweight validation tasks:
# 1 H1 only, 2 L1 only, 3 H1+L1, 4 H1+L1 with L1 notch, 5 narrow Ns=800/Nmu101.
sbatch --array=1-5%3 gw230518_validation_campaign/slurm_gw230518_validation.sh
squeue -u "$USER"
